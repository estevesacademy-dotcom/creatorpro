import argparse
import secrets
import string

import server


def generated_password():
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(12))


def list_requests():
    with server.db() as connection:
        rows = connection.execute(
            "SELECT name, email, whatsapp, crm, status, notification_sent, created_at FROM access_requests ORDER BY id DESC"
        ).fetchall()
    if not rows:
        print("Nenhuma solicitação cadastrada.")
        return
    for row in rows:
        print(
            f"[{row['status']}] {row['name']} | {row['email']} | {row['whatsapp']} | "
            f"{row['crm']} | e-mail enviado: {'sim' if row['notification_sent'] else 'não'} | {row['created_at']}"
        )


def approve(email, specialty, password):
    password = password or generated_password()
    server.approve_access_request(email, password, specialty)
    print("Acesso liberado com sucesso.")
    print(f"E-mail de acesso: {email.strip().lower()}")
    print(f"Senha temporária: {password}")
    print("Envie a senha ao médico por um canal seguro e solicite a troca no primeiro contato.")


def main():
    server.init_db()
    parser = argparse.ArgumentParser(description="Gerencia acessos da Med Creator PRO.")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list", help="Lista solicitações de acesso.")
    approve_parser = commands.add_parser("approve", help="Libera um cadastro pendente.")
    approve_parser.add_argument("--email", required=True)
    approve_parser.add_argument("--specialty", default="Clínica Médica")
    approve_parser.add_argument("--password")
    args = parser.parse_args()
    if args.command == "list":
        list_requests()
    elif args.command == "approve":
        approve(args.email, args.specialty, args.password)


if __name__ == "__main__":
    main()
