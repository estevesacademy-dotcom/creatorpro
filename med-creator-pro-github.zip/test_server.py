import http.client
import json
import os
import threading
import unittest
from unittest.mock import patch

import server
from http.server import ThreadingHTTPServer


AUDIT_EMAIL = "audit-user@example.com"


def clean_audit_user():
    with server.db() as connection:
        user = connection.execute("SELECT id FROM users WHERE username = ?", (AUDIT_EMAIL,)).fetchone()
        if user:
            connection.execute("DELETE FROM sessions WHERE user_id = ?", (user["id"],))
            connection.execute("DELETE FROM generations WHERE user_id = ?", (user["id"],))
            connection.execute("DELETE FROM instagram_metrics WHERE user_id = ?", (user["id"],))
            connection.execute("DELETE FROM instagram_connections WHERE user_id = ?", (user["id"],))
            connection.execute("DELETE FROM users WHERE id = ?", (user["id"],))
        connection.execute("DELETE FROM access_requests WHERE email = ?", (AUDIT_EMAIL,))


class ServerSmokeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        server.init_db()
        clean_audit_user()
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 4180), server.Handler)
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        clean_audit_user()

    def request(self, method, path, payload=None, cookie=None):
        connection = http.client.HTTPConnection("127.0.0.1", 4180, timeout=10)
        headers = {}
        body = None
        if payload is not None:
            body = json.dumps(payload)
            headers["Content-Type"] = "application/json"
        if cookie:
            headers["Cookie"] = cookie
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        data = json.loads(response.read().decode("utf-8"))
        return response, data

    def test_access_approval_profile_and_integrations(self):
        response, request_data = self.request(
            "POST",
            "/api/access-request",
            {"name": "Dra. Auditoria", "email": AUDIT_EMAIL, "whatsapp": "11999999999", "crm": "CRM/SP 1"},
        )
        self.assertEqual(response.status, 201)
        self.assertTrue(request_data["ok"])
        self.assertTrue(request_data["whatsapp_url"].startswith("https://wa.me/"))

        response, blocked = self.request(
            "POST",
            "/api/auth/login-or-register",
            {"username": AUDIT_EMAIL, "password": "senha123"},
        )
        self.assertEqual(response.status, 403)
        self.assertIn("não liberado", blocked["error"])

        server.approve_access_request(AUDIT_EMAIL, "senha123", "Dermatologia")
        response, login = self.request(
            "POST",
            "/api/auth/login-or-register",
            {"username": AUDIT_EMAIL, "password": "senha123"},
        )
        self.assertEqual(response.status, 200)
        cookie = response.getheader("Set-Cookie").split(";", 1)[0]

        response, me = self.request("GET", "/api/me", cookie=cookie)
        self.assertEqual(response.status, 200)
        self.assertEqual(me["user"]["specialty"], "Dermatologia")
        self.assertNotIn("password_hash", me["user"])

        response, status = self.request("GET", "/api/instagram/status", cookie=cookie)
        self.assertEqual(response.status, 200)
        self.assertEqual(status["imported_count"], 0)

        response, imported = self.request(
            "POST",
            "/api/instagram/import",
            {"rows": [{"id": "audit-post-1", "format": "reels", "caption": "Conteúdo educativo", "reach": 1200, "likes": 80, "comments": 9, "shares": 14, "saves": 22}]},
            cookie=cookie,
        )
        self.assertEqual(response.status, 200)
        self.assertEqual(imported["saved"], 1)

        response, imported = self.request("GET", "/api/instagram/import", cookie=cookie)
        self.assertEqual(response.status, 200)
        self.assertEqual(len(imported["rows"]), 1)
        self.assertEqual(imported["rows"][0]["reach"], 1200)

        response, oauth = self.request("GET", "/api/instagram/oauth/start", cookie=cookie)
        self.assertEqual(response.status, 503)
        self.assertIn("configure", oauth["error"])
        with patch.dict(
            os.environ,
            {
                "META_INSTAGRAM_CLIENT_ID": "instagram-app-id",
                "META_INSTAGRAM_CLIENT_SECRET": "instagram-app-secret",
                "META_INSTAGRAM_REDIRECT_URI": "https://app.example.com/api/instagram/oauth/callback",
            },
        ):
            self.assertTrue(server.instagram_oauth_ready())

        response, sync = self.request("GET", "/api/instagram/sync", cookie=cookie)
        self.assertEqual(response.status, 409)
        self.assertIn("OAuth", sync["error"])

        api_key = os.environ.pop("OPENAI_API_KEY", None)
        try:
            response, ai = self.request("POST", "/api/ai/scripts", {"theme": "melasma", "format": "Reels"}, cookie=cookie)
            self.assertEqual(response.status, 503)
            self.assertTrue(ai["fallback"])
        finally:
            if api_key:
                os.environ["OPENAI_API_KEY"] = api_key

        response, health = self.request("GET", "/api/health")
        self.assertEqual(response.status, 200)
        self.assertTrue(health["ok"])


if __name__ == "__main__":
    unittest.main()
