import base64
import hashlib
import hmac
import json
import os
import secrets
import shutil
import smtplib
import sqlite3
import subprocess
import threading
import time
import urllib.parse
from email.message import EmailMessage
from http import cookies
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def load_env_file():
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            os.environ.setdefault(key, value)


load_env_file()
DB_PATH = Path(os.getenv("MED_CREATOR_DB_PATH", str(ROOT / "med_creator.db"))).expanduser().resolve()
HOST = os.getenv("MED_CREATOR_HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", os.getenv("MED_CREATOR_PORT", "4173")))
SESSION_TTL = 60 * 60 * 24 * 30
COOKIE_SECURE = os.getenv("MED_CREATOR_COOKIE_SECURE", "").strip().lower() in {"1", "true", "yes", "on"}


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with db() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                specialty TEXT NOT NULL,
                crm TEXT DEFAULT '',
                rqe TEXT DEFAULT '',
                city TEXT DEFAULT '',
                services TEXT DEFAULT '',
                audience TEXT DEFAULT '',
                tone TEXT DEFAULT 'Acolhedor e técnico',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                expires_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS generations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                theme TEXT NOT NULL,
                format TEXT NOT NULL,
                payload TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS instagram_connections (
                user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                instagram_user_id TEXT DEFAULT '',
                username TEXT DEFAULT '',
                access_token TEXT NOT NULL,
                expires_at INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS instagram_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                media_id TEXT NOT NULL,
                media_type TEXT DEFAULT '',
                caption TEXT DEFAULT '',
                permalink TEXT DEFAULT '',
                timestamp TEXT DEFAULT '',
                reach INTEGER DEFAULT 0,
                likes INTEGER DEFAULT 0,
                comments INTEGER DEFAULT 0,
                shares INTEGER DEFAULT 0,
                saves INTEGER DEFAULT 0,
                UNIQUE(user_id, media_id)
            );
            CREATE TABLE IF NOT EXISTS access_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                whatsapp TEXT NOT NULL,
                crm TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                notification_sent INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            """
        )


def json_bytes(payload):
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def public_user(user):
    return {key: user[key] for key in ("id", "username", "name", "specialty", "crm", "rqe", "city", "services", "audience", "tone")}


def password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 180_000)
    return f"{base64.b64encode(salt).decode()}:{base64.b64encode(digest).decode()}"


def verify_password(password, encoded):
    salt_text, digest_text = encoded.split(":", 1)
    expected = base64.b64decode(digest_text)
    candidate = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), base64.b64decode(salt_text), 180_000
    )
    return hmac.compare_digest(candidate, expected)


def notify_access_request(request_data):
    if os.getenv("SMTP_ENABLED", "").strip().lower() not in {"1", "true", "yes", "on"}:
        return False
    host = os.getenv("SMTP_HOST", "").strip()
    username = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", "").strip()
    recipient = os.getenv("ACCESS_REQUEST_NOTIFY_EMAIL", "marcosestevees@icloud.com").strip()
    if not host or not username or not password or not recipient:
        return False
    port = int(os.getenv("SMTP_PORT", "587"))
    sender = os.getenv("SMTP_FROM", username).strip()
    subject = f"Novo cadastro Med Creator PRO: {request_data['name']}"
    body = "\n".join(
        [
            "Nova solicitação de acesso à Med Creator PRO.",
            "",
            f"Nome: {request_data['name']}",
            f"E-mail: {request_data['email']}",
            f"WhatsApp: {request_data['whatsapp']}",
            f"CRM: {request_data['crm']}",
            "",
            "O cadastro foi salvo como pendente. Libere o acesso manualmente após sua conferência.",
        ]
    )
    powershell = """
$ErrorActionPreference = 'Stop'
$secure = ConvertTo-SecureString $env:MED_SMTP_PASSWORD -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential($env:MED_SMTP_USER, $secure)
Send-MailMessage -SmtpServer $env:MED_SMTP_HOST -Port ([int]$env:MED_SMTP_PORT) -UseSsl `
  -Credential $credential -From $env:MED_SMTP_FROM -To $env:MED_SMTP_TO `
  -Subject $env:MED_SMTP_SUBJECT -Body $env:MED_SMTP_BODY -Encoding UTF8
"""
    environment = os.environ.copy()
    environment.update(
        {
            "MED_SMTP_HOST": host,
            "MED_SMTP_PORT": str(port),
            "MED_SMTP_USER": username,
            "MED_SMTP_PASSWORD": password,
            "MED_SMTP_FROM": sender,
            "MED_SMTP_TO": recipient,
            "MED_SMTP_SUBJECT": subject,
            "MED_SMTP_BODY": body,
        }
    )
    result = subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", powershell],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=environment,
        timeout=40,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Falha ao enviar e-mail.")
    return True


def notify_access_request_async(request_data):
    def worker():
        try:
            if notify_access_request(request_data):
                with db() as connection:
                    connection.execute("UPDATE access_requests SET notification_sent=1 WHERE email=?", (request_data["email"],))
        except Exception as error:
            print(f"[med-creator] Não foi possível enviar a notificação por e-mail: {error}")

    threading.Thread(target=worker, daemon=True).start()


def notify_access_request(request_data):
    if os.getenv("SMTP_ENABLED", "").strip().lower() not in {"1", "true", "yes", "on"}:
        return False
    host = os.getenv("SMTP_HOST", "").strip()
    username = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", "").strip()
    recipient = os.getenv("ACCESS_REQUEST_NOTIFY_EMAIL", "marcosestevees@icloud.com").strip()
    if not host or not username or not password or not recipient:
        return False
    message = EmailMessage()
    message["From"] = os.getenv("SMTP_FROM", username).strip()
    message["To"] = recipient
    message["Subject"] = f"Novo cadastro Med Creator PRO: {request_data['name']}"
    message.set_content(
        "Nova solicitacao de acesso a Med Creator PRO.\n\n"
        f"Nome: {request_data['name']}\n"
        f"E-mail: {request_data['email']}\n"
        f"WhatsApp: {request_data['whatsapp']}\n"
        f"CRM: {request_data['crm']}\n\n"
        "O cadastro foi salvo como pendente. Libere o acesso manualmente apos sua conferencia."
    )
    with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=40) as smtp:
        smtp.starttls()
        smtp.login(username, password)
        smtp.send_message(message)
    return True


def access_request_whatsapp_url(request_data):
    recipient = "".join(char for char in os.getenv("ACCESS_REQUEST_WHATSAPP", "5511924787933") if char.isdigit())
    text = urllib.parse.quote(
        "Novo cadastro Med Creator PRO\n"
        f"Nome: {request_data['name']}\n"
        f"E-mail: {request_data['email']}\n"
        f"WhatsApp: {request_data['whatsapp']}\n"
        f"CRM: {request_data['crm']}"
    )
    return f"https://wa.me/{recipient}?text={text}"


def notify_access_request_whatsapp(request_data):
    token = os.getenv("WHATSAPP_CLOUD_ACCESS_TOKEN", "").strip()
    phone_number_id = os.getenv("WHATSAPP_CLOUD_PHONE_NUMBER_ID", "").strip()
    recipient = "".join(char for char in os.getenv("ACCESS_REQUEST_WHATSAPP", "5511924787933") if char.isdigit())
    template_name = os.getenv("WHATSAPP_ACCESS_TEMPLATE", "").strip()
    language = os.getenv("WHATSAPP_ACCESS_TEMPLATE_LANGUAGE", "pt_BR").strip()
    if not token or not phone_number_id or not recipient or not template_name:
        return False
    json_api_request(
        f"https://graph.facebook.com/v23.0/{urllib.parse.quote(phone_number_id)}/messages",
        {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": recipient,
            "type": "template",
            "template": {
                "name": template_name,
                "language": {"code": language},
                "components": [
                    {
                        "type": "body",
                        "parameters": [
                            {"type": "text", "text": request_data["name"]},
                            {"type": "text", "text": request_data["email"]},
                            {"type": "text", "text": request_data["whatsapp"]},
                            {"type": "text", "text": request_data["crm"]},
                        ],
                    }
                ],
            },
        },
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        timeout=40,
    )
    return True


def notify_access_request_async(request_data):
    def worker():
        notification_sent = False
        try:
            notification_sent = notify_access_request(request_data) or notification_sent
        except Exception as error:
            print(f"[med-creator] Nao foi possivel enviar a notificacao por e-mail: {error}")
        try:
            notification_sent = notify_access_request_whatsapp(request_data) or notification_sent
        except Exception as error:
            print(f"[med-creator] Nao foi possivel enviar a notificacao por WhatsApp: {error}")
        if notification_sent:
            with db() as connection:
                connection.execute("UPDATE access_requests SET notification_sent=1 WHERE email=?", (request_data["email"],))

    threading.Thread(target=worker, daemon=True).start()


def approve_access_request(email, password, specialty="Clínica Médica"):
    normalized_email = email.strip().lower()
    with db() as connection:
        request_row = connection.execute("SELECT * FROM access_requests WHERE email = ?", (normalized_email,)).fetchone()
        if not request_row:
            raise ValueError("Solicitação de acesso não encontrada.")
        user = connection.execute("SELECT * FROM users WHERE username = ?", (normalized_email,)).fetchone()
        if not user:
            connection.execute(
                """
                INSERT INTO users(username, name, password_hash, specialty, crm)
                VALUES (?, ?, ?, ?, ?)
                """,
                (normalized_email, request_row["name"], password_hash(password), specialty, request_row["crm"]),
            )
        else:
            connection.execute(
                "UPDATE users SET name=?, password_hash=?, specialty=?, crm=?, updated_at=CURRENT_TIMESTAMP WHERE username=?",
                (request_row["name"], password_hash(password), specialty, request_row["crm"], normalized_email),
            )
        connection.execute(
            "UPDATE access_requests SET status='approved', updated_at=CURRENT_TIMESTAMP WHERE email=?",
            (normalized_email,),
        )


def api_request(url, method="GET", headers=None, data=None):
    command = curl_command(35, method)
    for key, value in (headers or {}).items():
        command.extend(["--header", f"{key}: {value}"])
    if data is not None:
        command.extend(["--data", urllib.parse.urlencode(data)])
    command.append(url)
    response = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if response.returncode:
        raise RuntimeError(f"Falha ao consultar integração externa: {response.stderr.strip() or response.stdout.strip()}")
    payload = json.loads(response.stdout)
    if payload.get("error"):
        raise RuntimeError(payload["error"].get("message", "A integração externa recusou a requisição."))
    return payload


def instagram_oauth_config():
    return {
        "client_id": os.getenv("META_INSTAGRAM_CLIENT_ID", "").strip(),
        "client_secret": os.getenv("META_INSTAGRAM_CLIENT_SECRET", "").strip(),
        "redirect_uri": os.getenv("META_INSTAGRAM_REDIRECT_URI", "").strip(),
        "scopes": os.getenv(
            "META_INSTAGRAM_SCOPES",
            "instagram_business_basic,instagram_business_manage_insights",
        ).strip(),
    }


def instagram_oauth_ready():
    config = instagram_oauth_config()
    return bool(config["client_id"] and config["client_secret"] and config["redirect_uri"].startswith("https://"))


def exchange_instagram_long_lived_token(short_lived_token):
    client_secret = instagram_oauth_config()["client_secret"]
    if not client_secret:
        return {"access_token": short_lived_token, "expires_in": 3600}
    query = urllib.parse.urlencode(
        {
            "grant_type": "ig_exchange_token",
            "client_secret": client_secret,
            "access_token": short_lived_token,
        }
    )
    return api_request(f"https://graph.instagram.com/access_token?{query}")


def refresh_instagram_token(access_token):
    query = urllib.parse.urlencode({"grant_type": "ig_refresh_token", "access_token": access_token})
    return api_request(f"https://graph.instagram.com/refresh_access_token?{query}")


def json_api_request(url, payload, headers=None, timeout=90):
    command = curl_command(timeout, "POST")
    for key, value in (headers or {}).items():
        command.extend(["--header", f"{key}: {value}"])
    command.extend(["--data", json.dumps(payload, ensure_ascii=False), url])
    response = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if response.returncode:
        raise RuntimeError(f"Falha ao consultar IA: {response.stderr.strip() or response.stdout.strip()}")
    data = json.loads(response.stdout)
    if data.get("error"):
        message = data["error"].get("message", "A OpenAI recusou a requisição.")
        raise RuntimeError(message)
    return data


def curl_command(timeout, method):
    executable = shutil.which("curl.exe") or shutil.which("curl")
    if not executable:
        raise RuntimeError("Instale o curl no servidor para ativar integrações externas e IA.")
    command = [executable, "--silent", "--show-error", "--max-time", str(timeout), "--request", method]
    if os.name == "nt":
        command.insert(3, "--ssl-no-revoke")
    return command


def session_cookie(value, max_age):
    secure = "; Secure" if COOKIE_SECURE else ""
    return f"med_creator_session={value}; Path=/; Max-Age={max_age}; HttpOnly; SameSite=Lax{secure}"


def openai_connection_status():
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    model = os.getenv("OPENAI_MODEL", "gpt-5.4-mini").strip()
    if not api_key:
        return {"configured": False, "active": False, "model": model}
    try:
        api_request(
            f"https://api.openai.com/v1/models/{urllib.parse.quote(model)}",
            headers={"Authorization": f"Bearer {api_key}"},
        )
        return {"configured": True, "active": True, "model": model}
    except Exception as error:
        return {"configured": True, "active": False, "model": model, "error": str(error)}


def openai_script(profile, payload):
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY não configurada no servidor.")
    model = os.getenv("OPENAI_MODEL", "gpt-5.4-mini")
    prompt = f"""
Você é o copiloto estratégico do Med Creator PRO para médicos brasileiros.
Crie um roteiro completo, específico e ético para Instagram. Responda APENAS em JSON válido.

Perfil do médico:
- Nome: {profile['name']}
- Especialidade: {profile['specialty']}
- CRM: {profile['crm']}
- RQE: {profile['rqe']}
- Cidade: {profile['city']}
- Serviços: {profile['services']}
- Público desejado: {profile['audience']}
- Tom de voz memorizado: {profile['tone']}

Pedido:
- Tema: {payload.get('theme', '')}
- Formato: {payload.get('format', '')}
- Tom solicitado: {payload.get('tone', '')}
- Observações: {payload.get('notes', '')}

Regras:
- Não diagnostique individualmente.
- Não prometa resultado.
- Inclua orientação para avaliação individual quando aplicável.
- Entregue direção de gravação, gancho visual, fala, legenda, CTA ético e reaproveitamento.
- Preserve sobriedade profissional.

Formato JSON:
{{
  "title": "string",
  "subtitle": "string",
  "blocks": [
    {{"label": "Objetivo estratégico", "text": "string"}},
    {{"label": "Gancho falado", "text": "string"}},
    {{"label": "Gancho visual", "text": "string"}},
    {{"label": "Como gravar", "text": "string"}},
    {{"label": "Roteiro de fala", "text": "string"}},
    {{"label": "Legenda pronta", "text": "string"}},
    {{"label": "CTA final", "text": "string"}},
    {{"label": "Reaproveitamento", "text": "string"}},
    {{"label": "Checklist ético", "text": "string"}}
  ]
}}
"""
    schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string"},
            "subtitle": {"type": "string"},
            "blocks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"label": {"type": "string"}, "text": {"type": "string"}},
                    "required": ["label", "text"],
                    "additionalProperties": False,
                },
            },
        },
        "required": ["title", "subtitle", "blocks"],
        "additionalProperties": False,
    }
    data = json_api_request(
        "https://api.openai.com/v1/responses",
        {
            "model": model,
            "input": prompt,
            "text": {"format": {"type": "json_schema", "name": "medical_script", "schema": schema, "strict": True}},
        },
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
    )
    output_text = data.get("output_text", "")
    if not output_text:
        parts = []
        for item in data.get("output", []):
            for content in item.get("content", []):
                if content.get("type") == "output_text":
                    parts.append(content.get("text", ""))
        output_text = "".join(parts)
    return json.loads(output_text)


def openai_instagram_screenshot(profile, payload):
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY não configurada no servidor.")
    image = str(payload.get("image", ""))
    if not image.startswith("data:image/"):
        raise RuntimeError("Envie um print válido em PNG, JPG ou WEBP.")
    schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string"},
            "subtitle": {"type": "string"},
            "metrics": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"value": {"type": "string"}, "label": {"type": "string"}},
                    "required": ["value", "label"],
                    "additionalProperties": False,
                },
            },
            "insights": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"label": {"type": "string"}, "text": {"type": "string"}},
                    "required": ["label", "text"],
                    "additionalProperties": False,
                },
            },
        },
        "required": ["title", "subtitle", "metrics", "insights"],
        "additionalProperties": False,
    }
    prompt = f"""
Analise o print real enviado por um médico brasileiro para a central Instagram Pro da Med Creator PRO.
Perfil logado: {profile['name']}, especialidade {profile['specialty']}, CRM {profile['crm']}.
Tipo de print informado: {payload.get('type', 'Perfil completo')}.
Usuário informado: {payload.get('username', '')}.
Entregue uma análise profissional, individualizada e objetiva do que estiver realmente visível.
Não invente métricas ausentes no print. Quando não estiver legível, declare que não foi possível confirmar.
Inclua clareza de perfil ou post, hierarquia visual, posicionamento, autoridade, CTA, conversão ética,
oportunidades de conteúdo e próximos testes. Não faça diagnóstico clínico e não prometa resultado.
"""
    data = json_api_request(
        "https://api.openai.com/v1/responses",
        {
            "model": os.getenv("OPENAI_MODEL", "gpt-5.4-mini"),
            "input": [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_image", "image_url": image},
                    ],
                }
            ],
            "text": {"format": {"type": "json_schema", "name": "instagram_screenshot_analysis", "schema": schema, "strict": True}},
        },
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
    )
    output_text = data.get("output_text", "")
    if not output_text:
        output_text = "".join(
            content.get("text", "")
            for item in data.get("output", [])
            for content in item.get("content", [])
            if content.get("type") == "output_text"
        )
    return json.loads(output_text)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        clean_path = self.path.split("?", 1)[0]
        if clean_path.startswith("/api/") or clean_path == "/" or clean_path.endswith(".html"):
            self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, format_string, *args):
        print(f"[med-creator] {self.address_string()} {format_string % args}")

    def send_json(self, payload, status=200, extra_headers=None):
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, text, status=200):
        body = str(text).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length).decode("utf-8") or "{}")

    def session_user(self):
        cookie = cookies.SimpleCookie(self.headers.get("Cookie", ""))
        token = cookie.get("med_creator_session")
        if not token:
            return None
        now = int(time.time())
        with db() as connection:
            connection.execute("DELETE FROM sessions WHERE expires_at < ?", (now,))
            return connection.execute(
                """
                SELECT users.* FROM users
                JOIN sessions ON sessions.user_id = users.id
                WHERE sessions.token = ? AND sessions.expires_at >= ?
                """,
                (token.value, now),
            ).fetchone()

    def require_user(self):
        user = self.session_user()
        if not user:
            self.send_json({"error": "Faça login para continuar."}, 401)
            return None
        return user

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/api/instagram/webhook":
            query = urllib.parse.parse_qs(parsed.query)
            verify_token = os.getenv("META_INSTAGRAM_WEBHOOK_VERIFY_TOKEN", "")
            supplied_token = (query.get("hub.verify_token") or [""])[0]
            challenge = (query.get("hub.challenge") or [""])[0]
            mode = (query.get("hub.mode") or [""])[0]
            if verify_token and mode == "subscribe" and hmac.compare_digest(supplied_token, verify_token):
                return self.send_text(challenge)
            return self.send_json({"error": "Verificação do webhook inválida."}, 403)
        if path == "/api/health":
            return self.send_json({"ok": True, "openai": bool(os.getenv("OPENAI_API_KEY"))})
        if path == "/api/health/openai":
            return self.send_json(openai_connection_status())
        if path == "/api/me":
            user = self.require_user()
            return None if not user else self.send_json({"user": public_user(user)})
        if path == "/api/instagram/status":
            user = self.require_user()
            if not user:
                return
            with db() as connection:
                imported_count = connection.execute(
                    "SELECT COUNT(*) AS total FROM instagram_metrics WHERE user_id = ?",
                    (user["id"],),
                ).fetchone()["total"]
                connection_row = connection.execute(
                    "SELECT username, updated_at FROM instagram_connections WHERE user_id = ?",
                    (user["id"],),
                ).fetchone()
            return self.send_json(
                {
                    "imported_count": imported_count,
                    "oauth_configured": instagram_oauth_ready(),
                    "connected": bool(connection_row),
                    "username": f"@{connection_row['username']}" if connection_row and connection_row["username"] else "",
                    "updated_at": connection_row["updated_at"] if connection_row else "",
                }
            )
        if path == "/api/instagram/import":
            user = self.require_user()
            if not user:
                return
            with db() as connection:
                rows = connection.execute(
                    """
                    SELECT media_id AS id, media_type AS format, caption, timestamp AS date,
                           reach, likes, comments, shares, saves
                    FROM instagram_metrics WHERE user_id = ? ORDER BY id DESC LIMIT 500
                    """,
                    (user["id"],),
                ).fetchall()
            return self.send_json({"rows": [dict(row) for row in rows]})
        if path == "/api/instagram/oauth/start":
            user = self.require_user()
            if not user:
                return
            config = instagram_oauth_config()
            if not instagram_oauth_ready():
                return self.send_json(
                    {"error": "Conexão oficial pendente: configure App ID, App Secret e uma URL HTTPS de callback no servidor."},
                    503,
                )
            state = secrets.token_urlsafe(24)
            with db() as connection:
                connection.execute(
                    "INSERT OR REPLACE INTO sessions(token, user_id, expires_at) VALUES (?, ?, ?)",
                    (f"oauth:{state}", user["id"], int(time.time()) + 900),
                )
            query = urllib.parse.urlencode(
                {
                    "client_id": config["client_id"],
                    "redirect_uri": config["redirect_uri"],
                    "response_type": "code",
                    "scope": config["scopes"],
                    "state": state,
                }
            )
            self.send_response(302)
            self.send_header("Location", f"https://www.instagram.com/oauth/authorize?{query}")
            self.end_headers()
            return
        if path == "/api/instagram/oauth/callback":
            query = urllib.parse.parse_qs(parsed.query)
            code = (query.get("code") or [""])[0]
            state = (query.get("state") or [""])[0]
            with db() as connection:
                oauth_session = connection.execute(
                    "SELECT user_id FROM sessions WHERE token = ? AND expires_at >= ?",
                    (f"oauth:{state}", int(time.time())),
                ).fetchone()
            if not code or not oauth_session:
                return self.send_json({"error": "Callback OAuth inválido."}, 400)
            config = instagram_oauth_config()
            token_data = api_request(
                "https://api.instagram.com/oauth/access_token",
                "POST",
                data={
                    "client_id": config["client_id"],
                    "client_secret": config["client_secret"],
                    "grant_type": "authorization_code",
                    "redirect_uri": config["redirect_uri"],
                    "code": code,
                },
            )
            long_lived = exchange_instagram_long_lived_token(token_data["access_token"])
            access_token = long_lived.get("access_token", token_data["access_token"])
            expires_at = int(time.time()) + int(long_lived.get("expires_in", 0) or 0)
            instagram_user_id = str(token_data.get("user_id", ""))
            profile = api_request(
                f"https://graph.instagram.com/me?{urllib.parse.urlencode({'fields': 'id,username', 'access_token': access_token})}"
            )
            with db() as connection:
                connection.execute(
                    """
                    INSERT INTO instagram_connections(user_id, instagram_user_id, username, access_token, expires_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(user_id) DO UPDATE SET instagram_user_id=excluded.instagram_user_id,
                    username=excluded.username, access_token=excluded.access_token,
                    expires_at=excluded.expires_at, updated_at=CURRENT_TIMESTAMP
                    """,
                    (oauth_session["user_id"], instagram_user_id or profile.get("id", ""), profile.get("username", ""), access_token, expires_at),
                )
                connection.execute("DELETE FROM sessions WHERE token = ?", (f"oauth:{state}",))
            self.send_response(302)
            self.send_header("Location", "/?instagram=connected")
            self.end_headers()
            return
        if path == "/api/instagram/sync":
            user = self.require_user()
            if not user:
                return
            return self.sync_instagram(user)
        return super().do_GET()

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/access-request":
            return self.create_access_request()
        if path == "/api/instagram/webhook":
            return self.send_json({"ok": True})
        if path == "/api/instagram/import":
            user = self.require_user()
            if not user:
                return
            payload = self.read_json()
            rows = payload.get("rows", [])
            if not isinstance(rows, list) or not rows:
                return self.send_json({"error": "Envie ao menos uma métrica válida."}, 400)
            with db() as connection:
                for index, row in enumerate(rows[:500]):
                    connection.execute(
                        """
                        INSERT INTO instagram_metrics(user_id, media_id, media_type, caption, timestamp, reach, likes, comments, shares, saves)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(user_id, media_id) DO UPDATE SET media_type=excluded.media_type,
                        caption=excluded.caption, timestamp=excluded.timestamp, reach=excluded.reach,
                        likes=excluded.likes, comments=excluded.comments, shares=excluded.shares, saves=excluded.saves
                        """,
                        (
                            user["id"],
                            str(row.get("id") or f"import-{int(time.time())}-{index}"),
                            str(row.get("format", "")),
                            str(row.get("caption", "")),
                            str(row.get("date", "")),
                            int(row.get("reach", 0) or 0),
                            int(row.get("likes", 0) or 0),
                            int(row.get("comments", 0) or 0),
                            int(row.get("shares", 0) or 0),
                            int(row.get("saves", 0) or 0),
                        ),
                    )
            return self.send_json({"ok": True, "saved": min(len(rows), 500)})
        if path == "/api/instagram/analyze-screenshot":
            user = self.require_user()
            if not user:
                return
            try:
                return self.send_json(openai_instagram_screenshot(user, self.read_json()))
            except Exception as error:
                return self.send_json({"error": str(error)}, 503)
        if path == "/api/auth/login-or-register":
            return self.login_or_register()
        if path == "/api/logout":
            cookie = cookies.SimpleCookie(self.headers.get("Cookie", ""))
            token = cookie.get("med_creator_session")
            if token:
                with db() as connection:
                    connection.execute("DELETE FROM sessions WHERE token = ?", (token.value,))
            return self.send_json({"ok": True}, extra_headers={"Set-Cookie": session_cookie("", 0)})
        if path == "/api/profile":
            user = self.require_user()
            if not user:
                return
            payload = self.read_json()
            with db() as connection:
                connection.execute(
                    """
                    UPDATE users SET name=?, specialty=?, crm=?, rqe=?, city=?, services=?, audience=?, tone=?, updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        payload.get("name", user["name"]),
                        payload.get("specialty", user["specialty"]),
                        payload.get("crm", user["crm"]),
                        payload.get("rqe", user["rqe"]),
                        payload.get("city", user["city"]),
                        payload.get("services", user["services"]),
                        payload.get("audience", user["audience"]),
                        payload.get("tone", user["tone"]),
                        user["id"],
                    ),
                )
            return self.send_json({"ok": True})
        if path == "/api/ai/scripts":
            user = self.require_user()
            if not user:
                return
            payload = self.read_json()
            try:
                result = openai_script(user, payload)
            except Exception as error:
                return self.send_json({"error": str(error), "fallback": True}, 503)
            with db() as connection:
                connection.execute(
                    "INSERT INTO generations(user_id, theme, format, payload) VALUES (?, ?, ?, ?)",
                    (user["id"], payload.get("theme", ""), payload.get("format", ""), json.dumps(result, ensure_ascii=False)),
                )
            return self.send_json(result)
        self.send_json({"error": "Endpoint não encontrado."}, 404)

    def login_or_register(self):
        payload = self.read_json()
        username = str(payload.get("username", "")).strip().lower()
        password = str(payload.get("password", ""))
        if not username or len(password) < 6:
            return self.send_json({"error": "Informe usuário e uma senha com pelo menos 6 caracteres."}, 400)
        with db() as connection:
            user = connection.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            if not user:
                return self.send_json({"error": "Acesso ainda não liberado. Envie seu cadastro e aguarde a aprovação."}, 403)
            if user and not verify_password(password, user["password_hash"]):
                return self.send_json({"error": "Senha incorreta."}, 401)
            if not user:
                connection.execute(
                    """
                    INSERT INTO users(username, name, password_hash, specialty, crm, rqe, city, services, audience, tone)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        username,
                        payload.get("name") or username,
                        password_hash(password),
                        payload.get("specialty") or "Clínica Médica",
                        payload.get("crm", ""),
                        payload.get("rqe", ""),
                        payload.get("city", ""),
                        payload.get("services", ""),
                        payload.get("audience", ""),
                        payload.get("tone", "Acolhedor e técnico"),
                    ),
                )
                user = connection.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            token = secrets.token_urlsafe(36)
            connection.execute("INSERT INTO sessions(token, user_id, expires_at) VALUES (?, ?, ?)", (token, user["id"], int(time.time()) + SESSION_TTL))
        header = session_cookie(token, SESSION_TTL)
        return self.send_json({"user": public_user(user)}, extra_headers={"Set-Cookie": header})

    def create_access_request(self):
        payload = self.read_json()
        request_data = {
            "name": str(payload.get("name", "")).strip(),
            "email": str(payload.get("email", "")).strip().lower(),
            "whatsapp": str(payload.get("whatsapp", "")).strip(),
            "crm": str(payload.get("crm", "")).strip(),
        }
        if not all(request_data.values()) or "@" not in request_data["email"]:
            return self.send_json({"error": "Preencha nome, e-mail válido, WhatsApp e CRM."}, 400)
        with db() as connection:
            connection.execute(
                """
                INSERT INTO access_requests(name, email, whatsapp, crm, status, updated_at)
                VALUES (?, ?, ?, ?, 'pending', CURRENT_TIMESTAMP)
                ON CONFLICT(email) DO UPDATE SET name=excluded.name, whatsapp=excluded.whatsapp,
                crm=excluded.crm, status='pending', updated_at=CURRENT_TIMESTAMP
                """,
                (request_data["name"], request_data["email"], request_data["whatsapp"], request_data["crm"]),
            )
        notify_access_request_async(request_data)
        return self.send_json(
            {
                "ok": True,
                "notification_sent": False,
                "whatsapp_url": access_request_whatsapp_url(request_data),
            },
            201,
        )

    def sync_instagram(self, user):
        with db() as connection:
            record = connection.execute("SELECT * FROM instagram_connections WHERE user_id = ?", (user["id"],)).fetchone()
        if not record:
            return self.send_json({"error": "Conecte o Instagram via OAuth primeiro."}, 409)
        token = record["access_token"]
        if record["expires_at"] and record["expires_at"] < int(time.time()) + 60 * 60 * 24 * 7:
            refreshed = refresh_instagram_token(token)
            token = refreshed.get("access_token", token)
            expires_at = int(time.time()) + int(refreshed.get("expires_in", 0) or 0)
            with db() as connection:
                connection.execute(
                    "UPDATE instagram_connections SET access_token=?, expires_at=?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?",
                    (token, expires_at, user["id"]),
                )
        media = api_request(
            f"https://graph.instagram.com/me/media?{urllib.parse.urlencode({'fields': 'id,caption,media_type,timestamp,permalink,like_count,comments_count', 'limit': 50, 'access_token': token})}"
        ).get("data", [])
        rows = []
        for item in media:
            metrics = {"reach": 0, "saved": 0, "shares": 0}
            try:
                insights = api_request(
                    f"https://graph.instagram.com/{item['id']}/insights?{urllib.parse.urlencode({'metric': 'reach,saved,shares', 'access_token': token})}"
                )
                for insight in insights.get("data", []):
                    metrics[insight["name"]] = insight.get("values", [{}])[0].get("value", 0)
            except Exception:
                pass
            row = {
                "id": item["id"], "format": item.get("media_type", ""), "caption": item.get("caption", ""),
                "reach": metrics["reach"], "likes": item.get("like_count", 0), "comments": item.get("comments_count", 0),
                "shares": metrics["shares"], "saves": metrics["saved"], "date": item.get("timestamp", ""), "permalink": item.get("permalink", "")
            }
            rows.append(row)
        with db() as connection:
            for row in rows:
                connection.execute(
                    """
                    INSERT INTO instagram_metrics(user_id, media_id, media_type, caption, permalink, timestamp, reach, likes, comments, shares, saves)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(user_id, media_id) DO UPDATE SET media_type=excluded.media_type, caption=excluded.caption,
                    permalink=excluded.permalink, timestamp=excluded.timestamp, reach=excluded.reach, likes=excluded.likes,
                    comments=excluded.comments, shares=excluded.shares, saves=excluded.saves
                    """,
                    (user["id"], row["id"], row["format"], row["caption"], row["permalink"], row["date"], row["reach"], row["likes"], row["comments"], row["shares"], row["saves"]),
                )
        return self.send_json({"user": f"@{record['username']}", "rows": rows, "updatedAt": int(time.time())})


if __name__ == "__main__":
    init_db()
    print(f"Med Creator PRO disponível em http://{HOST}:{PORT}/")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
